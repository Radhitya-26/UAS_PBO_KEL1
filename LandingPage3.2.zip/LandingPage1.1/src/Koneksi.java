import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Koneksi {

    private Connection koneksi;

    public Connection connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Berhasil Koneksi");
        } catch (ClassNotFoundException ex) {
            System.out.println("Gagal Koneksi: " + ex.getMessage());
            return null;  // Return null to indicate connection failure
        }

        String url = "jdbc:mysql://localhost:3307/login?useSSL=false";
        try {
            koneksi = DriverManager.getConnection(url, "root", "");
            System.out.println("Berhasil Koneksi Database");
        } catch (SQLException ex) {
            System.out.println("Gagal Koneksi Database: " + ex.getMessage());
            return null;  // Return null to indicate connection failure
        }
        return koneksi;
    }

    public Connection getConnection() {
        return koneksi;
    }
}
